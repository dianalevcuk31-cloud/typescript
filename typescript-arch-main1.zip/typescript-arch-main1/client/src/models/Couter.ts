export interface Counter{
    name: string
    state:number
}