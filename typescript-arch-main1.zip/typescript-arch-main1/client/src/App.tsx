import React from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios'
function App() {

  useEffect(() => {
    getHello()
  }, [])


 const getHello = async () => {
   const req = await axios.get("http://localhost:3000/api/hello")
   console.log(req)
 }

  return (
    <div className="App">
      {counter.name} - {counter.state}
      <div onClick={() => setCounter(prev => ({...prev, state: prev.state + 1}))}>
        +
      </div>
       <div onClick={() => setCounter(prev => ({...prev, state: prev.state - 1}))}>
        -
      </div>
      <input 
          type="text"
          value={counter.name}
          onChange= {e => setCounter (prev => ({...prev, name: e.target.value}))}
          />  
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>dfsdfsdf</p>
        <p>
          Edit <code>src/App.tsx</code> and save to reload.
        </p>
        <a
         className="App-link" 
        href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer">
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
