import { ReactNode } from "react"

interface IUIButton {
    children: ReactNode
    onClick?: (e: React.MouseEvent<HTMLDivElement>) => void
}

const UIButton =() => {
    return(
        <div onClick={() => {}}>
             {props.children}
        </div>
    )
}

//<UIButton></UIButton>
export default UIButton